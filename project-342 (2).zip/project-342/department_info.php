<div style='display:flex;'>
<div class='button ' id='remove_department'>Remove  &nbsp <i class='bx bx-trash-alt'></i></div>
<div class='button add_to_department' id='add_to_department'>Add  &nbsp <i class='bx bx-plus'></i></div>
<div class='button ' id='edit_courses'>Courses  &nbsp <i class='bx bx-book' ></i></div>
</div>
<div class='load_av_departments'>

</div>
<script>
    $("#add_to_department").click(function(){
        start_loader();
        $("#data_change_232").text("Add new department");
        $("#get_data_3432").load("add_department.php",function(){
        stop_loader();
        $(".sidepart").removeClass("noner");
        })
    })


    $(".load_av_departments").load("department_data.php");
    $("#edit_courses").click(function(){
        $(".load_av_departments").load("courses_data.php");
    })


    $("#remove_department").click(function(){
          $.ajax({
          url:"data_controller.php",
          type:"post",
          async:false,
          data:{
              "rem":"rem"
          },success:function(data){
              stop_loader();
              show_pop("Data removed");
             $("#load_data2").load("shy.php");
                $("#load_data1").load("department_lists.php");
          }
      })
    })


</script>