<style>
    .row_item{
        display:flex;
        width:100%;
        justify-content:space-evenly;
        height:9rem;
        align-items:center;
        padding:1rem;
        overflow-x:scroll;
        overflow-y:hidden;

    }
    .row_item::-webkit-scrollbar{
        background-color:transparent;
    }
    .row_item::-webkit-scrollbar-thumb{
       border-radius:30px;
       background-color:rgba(138, 43, 226, 0.09);
    }
    .row_item_data2{
        text-transform:lowercase;
        color:black !important;
        font-weight:bold;
    }
    .row_item_data i{
        font-size:2rem;
        color: grey;
        cursor:pointer;
    }
    *{
        user-select:text !important;
    }
</style>
<?php
session_start();
include("init.php");
$query = mysqli_query($init_sec, "SELECT * FROM student_registration");
$num = mysqli_num_rows($query);
if($num < 1){
  ?>
  <div>
      <div class='msg'> 
       There are currently no registered students
  </div>
  </div>
  <?php
}
while($array = mysqli_fetch_array($query)){
    $uni239341 = $array['unique_id'];
    $course = $array['course'];
    $programme = $array['programme'];
    $first_name = $array['first_name'];
    $middle_name = $array['middle_name'];
    $last_name = $array['last_name'];
    $gender = $array['gender'];
    $home_address = $array['home_address'];
    $phone_number = $array['phone_number'];
    $whatsapp_number = $array['whatsapp_number'];
    $institutions = $array['institutions_attended'];
    $certification_id = $array['certifications_id'];
    $resolved = $array['resolved'];
    $date_enrolled = $array['date'];
    ?>
    <div class='row_item data4<?php echo $uni239341  ?>' style='border-bottom: none !important;display:flex;width:100%;align-items:center;justify-content:space-between'>
    <div  class='row_item_data' style='width:10rem;min-width:10rem'> <div data-get='<?php echo $uni239341  ?> ' style='font-size:11px !important;' class='button <?php if($resolved){echo "active_button";}  ?> get_resolution'>Resolved</div></div>
    <div  class='row_item_data' style='width:20rem;min-width:20rem'> <span ><?php echo "$first_name $middle_name $last_name"; ?> </span> </div>
    <div style='min-width:10rem;background-color:#fff' class='row_item_data'><?php echo $programme ?> </div>
    <div style='width:10rem;min-width:20rem;' class='row_item_data'><?php echo $course ?></div>
    <div style='min-width:10rem;' class='row_item_data'><?php echo $gender ?></div>
    <div style='min-width:30rem;' class='row_item_data'><?php echo $home_address ?></div>
    <div style='min-width:10rem;' class='row_item_data'><?php echo $phone_number ?></div>
    <div style='min-width:10rem;' class='row_item_data'><?php echo $whatsapp_number ?></div>
    <div style='min-width:30rem;' class='row_item_data'><?php echo $institutions ?></div>
    <div style='min-width:20rem;' class='row_item_data'><?php echo $date_enrolled?></div>
</div>
<?php
}
?>
<script>
    $(".get_resolution").click(function(){
        let data_res = $(this).attr("data-get");
         $(this).addClass("active_button")
        let rem_hide = document.querySelector(".data4"+data_res);
        $.ajax({
            url:"data_controller.php",
            type:"POST",
            async:false,
            data:{
                "data_res":data_res
            },success:function(data){
            
            }
        })
    })
</script>



