<?php
$url = "localhost";
$username = "root";
$password = "introversy900##";
$database = "elearn";
$init_sec = mysqli_connect($url, $username, $password, $database);
date_default_timezone_set("UTC");
$date = date('Y-m-d H:i:s ', time());
if(isset($_SESSION['cloudcat_data_sec'])){
 $cloudcat_citizen = $_SESSION['cloudcat_data_sec'];
    $query = mysqli_query($init_sec, "SELECT * FROM students_ WHERE unique_id = '$cloudcat_citizen'");
    $array = mysqli_fetch_array($query);
    $username = $array['username'];
    $student_name = $array['student_name'];
    $student_email = $array['student_email'];
    $student_department = $array['student_department'];
    $student_phone = $array['student_phone'];
    $student_programme = $array['programme'];
    $student_semester = $array['semester'];
    $student_access = $array['student_access'];
    $avatar = $array['avatar'];
    if(!$avatar){
        $avatar = 'avatar_23.png';
    }
}