<?php
$url = "localhost";
$username = "root";
$password = "introversy900##";
$database = "elearn";
$database_sec = "siitafrica";
$init = mysqli_connect($url, $username, $password, $database);
$init_sec = mysqli_connect($url, $username, $password, $database_sec);
date_default_timezone_set("UTC");
$date = date('Y-m-d H:i:s ', time());

