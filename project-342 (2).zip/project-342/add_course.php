<form class='course_add'>
<input type="text" id='course_data' placeholder='course name'>
<div class='button' id='add_to_course_1'>Done  </div>
</form>
<div>
    <img src="Flame_Design_Science_transparent_by_Icons8.gif" alt="">
</div>

<script>
    $("#add_to_course_1").click(function(){
      let course_data = document.getElementById("course_data");
      if(course_data.value.length < 1){
          show_pop_wrong("Fill field");
      }else{
      start_loader();
      $.ajax({
          url:"data_controller.php",
          type:"post",
          async:false,
          data:{
              "course_data":course_data.value
          },success:function(){
              course_data.value = "";
              stop_loader();
              show_pop("Data saved");
                $(".load_av_departments").load("courses_data.php");
          }
      })
      }
    })
    $(".button").click(function(){
    var button = document.querySelectorAll(".button");
    button.forEach((btn) => {
    btn.classList.remove("button_active");
    this.classList.add("button_active");
    })
    })
</script>