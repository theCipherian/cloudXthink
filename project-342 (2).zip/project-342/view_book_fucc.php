<div class='other_cont'>
<img src="miscellaneous_icons_1.png" alt="">
<div class='item_holder_98'>
    <div class='head_98'> Description</div>
    <div class='desc_98'>The Art of Computer Programming is a comprehensive monograph written by computer scientist Donald Knuth that covers many kinds of programming algorithms and their analysis.</div>
    <div class='head_98'> Pages</div>
    <div class='desc_98'>98 pages</div>
    <div class='head_98'> Estimated read time</div>
    <div class='desc_98'>58 mins</div>
    <div class='head_98'> file size</div>
    <div class='desc_98'>45mb</div>
</div>
</div>
<div class='action_384'>
<div class='button '>Read &nbsp  <i class='bx bx-right-arrow-alt'></i></div>
<div class='button '>Download &nbsp  <i class='bx bx-right-arrow-alt'></i></div>
</div>
</div>