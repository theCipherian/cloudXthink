<style>
    .row_item{
        display:flex;
        width:100%;
        justify-content:space-evenly;
        height:6rem;
        align-items:center;
        padding:1rem;
        border-bottom:1px solid #ddd;
    }
    .row_item_data1{
        text-transform:uppercase;
    color:blueviolet;
        font-weight:bold;
    }
    .row_item_data i{
        font-size:2rem;
        color: grey;
        cursor:pointer;
    }
</style>